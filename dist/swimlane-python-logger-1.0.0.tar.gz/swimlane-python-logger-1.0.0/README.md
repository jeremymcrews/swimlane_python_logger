# Swimlane Python Logger

Logger wrapper class for Swimlane Integrations.